<?php
$_['d_blog_module_demo'] = array(
    'text'        => 'Blog',
    'description' => '<h4>Dados de demonstração para o blog básico</h4><p>Você substituirá todas as postagens, categorias, revisões e autores do blog pelas configurações padrão. É um ótimo ponto de partida para entender como o Módulo Blog funciona. Você pode editar as postagens para atender às suas necessidades. Lembre-se de que esta opção excluirá tudo o que você já possui no seu blog, portanto, tenha cuidado. Aconselhamos você a fazer um backup do banco de dados primeiro.</p>',
    'sql'         => 'd_blog_module.sql'
);
