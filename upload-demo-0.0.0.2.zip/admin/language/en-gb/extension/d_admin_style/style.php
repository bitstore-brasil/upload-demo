<?php
$_['entry_admin_style']     = 'Admin style';