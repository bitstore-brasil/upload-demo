<?php

$_['field_require']             = 'Field is require';
$_['text_edit']                 = 'License Manager';
$_['license_confirmed']         = 'You activation key is confirmed!';
$_['license_expired']           = 'You activation key for "%s" is expired or module is not activated yet!';
$_['license_expired_not_found'] = 'You activation key is expired or does not exist!';
$_['license_is_expired']        = 'You activation key is expired. Please purchase module again!';
$_['license_is_valid']          = 'You activation key is valid. Thank you for use shopunity!';

$_['license_error']             = 'Something wrong with your key!';
$_['license_error_url']         = "This license doesn't belongs to domain!";
$_['license_error_codename']    = "This license doesn't belongs to module!";


$_['license_visit_text_under']  = '<p style="margin-top: 10px">Contact support<a href="https://dreamvention.ee/support" target="_blank">Shopunity.net</a> <br> Find more amazing extensions at <a href="https://dreamvention.ee/" target="_blank">Dreamvention.ee</a></p>';
$_['license_visit_text']		= 'Please contact support if you have some troubles with license <a href="https://dreamvention.ee/support" target="_blank">Shopunity.net</a> <br> Find more amazing extensions at <a href="https://dreamvention.ee/" target="_blank">Dreamvention.ee</a>';